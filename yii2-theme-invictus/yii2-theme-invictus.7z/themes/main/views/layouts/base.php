<?php

use yii\helpers\Html;

?>

<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?php echo Yii::$app->language; ?>">
    <head>
        <meta charset="<?php echo Yii::$app->charset; ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php echo Html::csrfMetaTags(); ?>
        <base href="<?php echo Yii::$app->urlManager->createAbsoluteUrl(''); ?>"></base>
        <title><?php echo Html::encode($this->title); ?></title>
        <?php $this->head(); ?>
        <script src="/theme-invictus/vendor/modernizr-2.8.3/modernizr.custom.js"></script>
    </head>
    <body>
        <?php $this->beginBody(); ?>
            <!-- Content -->
            <?php echo $content; ?>
            <!-- Footer -->
            <div id="footer" class="text-center">
                <div class="container">
                  <p>Copyright &copy; Invictus. Modify by <a href="http://drivesource.co" rel="nofollow">DRIVESOURCE.C/O</a></p>
                </div>
            </div>
        <?php $this->endBody(); ?>
    </body>
</html>
<?php $this->endPage(); ?>