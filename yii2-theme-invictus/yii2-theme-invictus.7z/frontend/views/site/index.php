<?php

$this->title = 'My Yii Application';

?>
    <!-- ============= Header ============= -->
    <header class="text-center" name="home">
        <div class="intro-text">
            <h1 class="wow zoomIn">Welcome to <span class="brand">Invictus</span></h1>
            <p class="wow fadeInDown" data-wow-delay="600ms">We are a full service creative digital agency</p>
            <div class="clearfix"></div>
            <a href="#about-section" class="btn btn-default btn-lg page-scroll wow fadeInDown" data-wow-delay="1000ms">Find Out More</a> 
        </div>
    </header>
		
    <!-- About Section -->
    <div id="about-section">
        <div class="container">
            <div class="row">
                <div class="section-title text-center center wow fadeInDown">
                    <h2>About us</h2><hr />
                </div>
                <div class="row wow fadeInDown" data-wow-delay="200ms">
                    <div class="col-md-6"> <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/about.jpg'); ?>" class="img-responsive center-block"> </div>
                    <div class="col-md-6">
                        <div class="about-text">
                            <h3><span class="color">Who</span> we are</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at. Duis sed dapibus leo nec ornare diam commodo nibh.</p>
                            <h3><span class="color">What</span> we do</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at. Duis sed dapibus leo nec ornare diam.</p>
                            <h3><span class="color">Our</span> philosophy</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at. Duis sed dapibus leo nec ornare diam.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Achievements Section -->
    <div id="achievements" class="text-center">
        <div class="container">
            <div class="space"></div>
            <div class="row wow fadeInDown" data-wow-delay="400ms">
                <div class="col-md-3 col-sm-3">
                    <div class="achievement-box"> <span class="count">120</span><h4>Happy clients</h4></div>
                </div>
                <div class="col-md-3 col-sm-3">
                    <div class="achievement-box"> <span class="count">4,600</span><h4>Working hours</h4></div>
                </div>
                <div class="col-md-3 col-sm-3">
                    <div class="achievement-box"> <span class="count">340</span><h4>Projects completed</h4> </div>
                </div>
                <div class="col-md-3 col-sm-3">
                    <div class="achievement-box"> <span class="count">23</span><h4>Awards won</h4></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Services Section -->
    <div id="services-section" class="text-center">
        <div class="container">
            <div class="section-title center wow fadeInDown">
                <h2>Our Services</h2><hr />
                <div class="clearfix"></div>
            </div>
            <div class="row wow fadeInDown" data-wow-delay="200ms">
                <div class="col-md-3 col-sm-6 service"> <i class="fa fa-desktop"></i>
                    <h4>Web design</h4>
                    <p>Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque natoque etiam.</p>
                </div>
                <div class="col-md-3 col-sm-6 service"> <i class="fa fa-gears"></i>
                    <h4>App Development</h4>
                    <p>Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque.</p>
                </div>
                <div class="col-md-3 col-sm-6 service"> <i class="fa fa-pie-chart"></i>
                    <h4>Analystics</h4>
                    <p>Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque natoque etiam.</p>
                </div>
                <div class="col-md-3 col-sm-6 service"> <i class="fa fa-line-chart"></i>
                    <h4>Marketing</h4>
                    <p>Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque natoque.</p>
                </div>
            </div>
            <div class="space"></div>
            <div class="row wow fadeInDown" data-wow-delay="400ms">
                <div class="col-md-3 col-sm-6 service"> <i class="fa fa-shopping-cart"></i>
                    <h4>eCommerce</h4>
                    <p>Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque natoque etiam.</p>
                </div>
                <div class="col-md-3 col-sm-6 service"> <i class="fa fa-file-text-o"></i>
                    <h4>Content Development</h4>
                    <p>Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque.</p>
                </div>
                <div class="col-md-3 col-sm-6 service"> <i class="fa fa-rocket"></i>
                    <h4>Branding</h4>
                    <p>Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque natoque etiam.</p>
                </div>
                <div class="col-md-3 col-sm-6 service"> <i class="fa fa-camera"></i>
                    <h4>Video & Photography</h4>
                    <p>Lorem ipsum dolor sit amet placerat facilisis felis mi in tempus eleifend pellentesque natoque.</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Portfolio Section -->
    <div id="works-section">
        <div class="container"> <!-- Container -->
            <div class="section-title text-center wow fadeInDown">
                <h2>Our Portfolio</h2><hr />
                <div class="clearfix"></div>
            </div>    
            <div class="categories wow fadeInDown">
                <ul class="cat">
                    <li>
                        <ol class="type">
                            <li><a href="#" data-filter="*" class="active">All</a></li>
                            <li><a href="#" data-filter=".web">Web Design</a></li>
                            <li><a href="#" data-filter=".app">App Development</a></li>
                            <li><a href="#" data-filter=".branding">Branding</a></li>
                        </ol>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="portfolio-items">
                    <div class="col-sm-6 col-md-3 col-lg-3 web">
                        <div class="portfolio-item wow fadeInDown" data-wow-delay="200ms">
                            <div class="hover-bg"> <a href="#portfolioModal1" class="portfolio-link" data-toggle="modal">
                                <div class="hover-text">
                                    <h4>Project Title</h4>
                                    <p>Web Design</p>
                                    <div class="clearfix"></div>
                                </div>
                                <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/01.jpg'); ?>" class="img-responsive" alt="Project Title"> </a> 
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 app">
                        <div class="portfolio-item wow fadeInDown" data-wow-delay="400ms">
                            <div class="hover-bg"> <a href="#portfolioModal2" class="portfolio-link" data-toggle="modal">
                                <div class="hover-text">
                                    <h4>Project Title</h4>
                                    <p>App Development</p>
                                    <div class="clearfix"></div>
                                </div>
                                <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/02.jpg'); ?>" class="img-responsive" alt="Project Title"> </a> 
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 web">
                        <div class="portfolio-item wow fadeInDown" data-wow-delay="600ms">
                            <div class="hover-bg"> <a href="#portfolioModal3" class="portfolio-link" data-toggle="modal">
                                <div class="hover-text">
                                    <h4>Project Title</h4>
                                    <p>Web Design</p>
                                    <div class="clearfix"></div>
                                </div>
                                <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/03.jpg'); ?>" class="img-responsive" alt="Project Title"> </a> 
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 web">
                        <div class="portfolio-item wow fadeInDown" data-wow-delay="800ms">
                            <div class="hover-bg"> <a href="#portfolioModal4" class="portfolio-link" data-toggle="modal">
                                <div class="hover-text">
                                    <h4>Project Title</h4>
                                    <p>Web Design</p>
                                    <div class="clearfix"></div>
                                    <i class="fa fa-plus"></i> 
                                </div>
                                <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/04.jpg'); ?>" class="img-responsive" alt="Project Title"> </a> 
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 app">
                        <div class="portfolio-item wow fadeInDown" data-wow-delay="1000ms">
                            <div class="hover-bg"> <a href="#portfolioModal5" class="portfolio-link" data-toggle="modal">
                                <div class="hover-text">
                                    <h4>Project Title</h4>
                                    <p>App Development</p>
                                    <div class="clearfix"></div>
                                </div>
                                <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/05.jpg'); ?>" class="img-responsive" alt="Project Title"> </a> 
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 branding">
                        <div class="portfolio-item wow fadeInDown" data-wow-delay="1200ms">
                            <div class="hover-bg"> <a href="#portfolioModal6" class="portfolio-link" data-toggle="modal">
                                <div class="hover-text">
                                    <h4>Project Title</h4>
                                    <p>Branding</p>
                                    <div class="clearfix"></div>
                                </div>
                                <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/06.jpg'); ?>" class="img-responsive" alt="Project Title"> </a> 
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 branding app">
                        <div class="portfolio-item wow fadeInDown" data-wow-delay="1400ms">
                            <div class="hover-bg"> <a href="#portfolioModal7" class="portfolio-link" data-toggle="modal">
                                <div class="hover-text">
                                    <h4>Project Title</h4>
                                    <p>App Development, Branding</p>
                                    <div class="clearfix"></div>
                                </div>
                                <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/07.jpg'); ?>" class="img-responsive" alt="Project Title"> </a> 
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 web">
                        <div class="portfolio-item wow fadeInDown" data-wow-delay="1600ms">
                            <div class="hover-bg"> <a href="#portfolioModal8" class="portfolio-link" data-toggle="modal">
                                <div class="hover-text">
                                    <h4>Project Title</h4>
                                    <p>Web Design</p>
                                    <div class="clearfix"></div>
                                </div>
                                <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/08.jpg'); ?>" class="img-responsive" alt="Project Title"> </a> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Team Section -->
    <div id="team-section" class="text-center">
        <div class="container">
            <div class="section-title wow fadeInDown">
                <h2>Meet our Team</h2><hr />
                <div class="clearfix"></div>
                <div class="space"></div>
            </div>
            <div id="row" class="wow fadeInDown" data-wow-delay="200ms">
                <div class="col-md-3 col-sm-6 team">
                    <div class="thumbnail"> <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/team/01.jpg'); ?>" alt="..." class="team-img">
                        <div class="caption">
                            <h3>Jessica Wally</h3>
                            <p>CEO / Founder</p>
                            <ul class="list-inline">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 team">
                    <div class="thumbnail"> <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/team/02.jpg'); ?>" alt="..." class="team-img">
                        <div class="caption">
                            <h3>Mike Sloan</h3>
                            <p>Web Designer</p>
                            <ul class="list-inline">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 team">
                    <div class="thumbnail"> <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/team/03.jpg'); ?>" alt="..." class="team-img">
                        <div class="caption">
                            <h3>Michele Doe</h3>
                            <p>Web Designer</p>
                            <ul class="list-inline">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 team">
                    <div class="thumbnail"> <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/team/04.jpg'); ?>" alt="..." class="team-img">
                        <div class="caption">
                            <h3>Larry Evans</h3>
                            <p>Project Manager</p>
                            <ul class="list-inline">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Testimonials Section -->
    <div id="testimonials-section" class="text-center">
        <div class="container">
            <div class="section-title wow fadeInDown">
                <h2>What our Clients say</h2><hr />
                <div class="clearfix"></div>
            </div>
            <div class="row">
                <div class="col-md-8 col-md-offset-2 wow fadeInDown" data-wow-delay="200ms">
                    <div id="testimonial" class="owl-carousel owl-theme">
                        <div class="item"> <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/clients/01.jpg'); ?>" alt=""/>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at duis sed dapibus leo nec ornare diam.</p>
                            <p><strong>John DOE</strong>, CEO, Company.</p>
                        </div>
                        <div class="item"> <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/clients/02.jpg'); ?>" alt=""/>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at duis sed dapibus leo nec ornare diam.</p>
                            <p><strong>Jenny DOE</strong>, CEO, Company.</p>
                        </div>
                        <div class="item"> <img src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/clients/03.jpg'); ?>" alt=""/>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis sed dapibus leo nec ornare diam. Sed commodo nibh ante facilisis bibendum dolor feugiat at duis sed dapibus leo nec ornare diam.</p>
                            <p><strong>John DOEn</strong>, CEO, Company.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Contact Section -->
    <div id="contact-section">
        <div class="container">
            <div class="section-title text-center wow fadeInDown">
                <h2>Contact us</h2><hr />
                <div class="clearfix"></div>
            </div>
            <div class="col-md-4 wow fadeInDown" data-wow-delay="200ms">
                <h3>Contact Info</h3>
                <div class="space"></div>
                <p><i class="fa fa-map-marker fa-fw pull-left fa-2x"></i>321 Awesome Street <br />New York, NY 17022</p>
                <div class="space"></div>
                <p><i class="fa fa-envelope-o fa-fw pull-left fa-2x"></i>info@companyname.com</p>
                <div class="space"></div>
                <p><i class="fa fa-phone fa-fw pull-left fa-2x"></i>+1 800 123 1234</p>
            </div>
            <div class="col-md-8 wow fadeInDown" data-wow-delay="200ms">
                <h3>Leave us a message</h3>
                <form name="sentMessage" id="contactForm" novalidate>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" id="name" class="form-control" placeholder="Name" required="required">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="email" id="email" class="form-control" placeholder="Email" required="required">
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <textarea name="message" id="message" class="form-control" rows="4" placeholder="Message" required></textarea>
                        <p class="help-block text-danger"></p>
                    </div>
                    <div id="success"></div>
                    <button type="submit" class="btn btn-default">Send Message</button>
                </form>
            </div>
        </div>
    </div>
    <div id="social-section">
        <div class="container">
            <div class="social">
                <ul>
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                    <li><a href="#"><i class="fa fa-github"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    
    <!-- Portfolio Modal 1 -->
    <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal"><div class="lr"> <div class="rl"> </div></div></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body"> 
                            <h2>Project Title</h2>
                            <p class="item-intro">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class="img-responsive img-centered" src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/01-preview.jpg'); ?>" alt="">
                            <p>Lorem ipsum dolor sit amet, sea essent iisque iudicabit te, pro no justo delicata inimicus et oblique docendi laboramus eum. Ei minim fabulas pertinacia pro graeco urbanitas reformidans quoid.</p>
                            <ul class="list-inline">
                                <li><span>Client</span>: John Doe</li>
                                <li><span>Service</span>: Web Design</li>
                            </ul>
                            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Portfolio Modal 2 -->
    <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal"><div class="lr"><div class="rl"> </div></div></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body"> 
                            <h2>Project Title</h2>
                            <p class="item-intro">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class="img-responsive img-centered" src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/02-preview.jpg'); ?>" alt="">
                            <p>Lorem ipsum dolor sit amet, sea essent iisque iudicabit te, pro no justo delicata inimicus et oblique docendi laboramus eum. Ei minim fabulas pertinacia pro graeco urbanitas reformidans quoid.</p>
                            <ul class="list-inline">
                                <li><span>Client</span>: John Doe</li>
                                <li><span>Service</span>: Web Design</li>
                            </ul>
                            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Portfolio Modal 3 -->
    <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal"><div class="lr"><div class="rl"> </div></div></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body"> 
                            <h2>Project Title</h2>
                            <p class="item-intro">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class="img-responsive img-centered" src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/03-preview.jpg'); ?>" alt="">
                            <p>Lorem ipsum dolor sit amet, sea essent iisque iudicabit te, pro no justo delicata inimicus et oblique docendi laboramus eum. Ei minim fabulas pertinacia pro graeco urbanitas reformidans quoid.</p>
                            <ul class="list-inline">
                                <li><span>Client</span>: John Doe</li>
                                <li><span>Service</span>: Web Design</li>
                            </ul>
                            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Portfolio Modal 4 -->
    <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal"><div class="lr"><div class="rl"> </div></div></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body"> 
                            <h2>Project Title</h2>
                            <p class="item-intro">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class="img-responsive img-centered" src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/04-preview.jpg'); ?>" alt="">
                            <p>Lorem ipsum dolor sit amet, sea essent iisque iudicabit te, pro no justo delicata inimicus et oblique docendi laboramus eum. Ei minim fabulas pertinacia pro graeco urbanitas reformidans quoid.</p>
                            <ul class="list-inline">
                                <li><span>Client</span>: John Doe</li>
                                <li><span>Service</span>: Web Design</li>
                            </ul>
                            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Portfolio Modal 5 -->
    <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal"><div class="lr"><div class="rl"> </div></div></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body"> 
                            <h2>Project Title</h2>
                            <p class="item-intro">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class="img-responsive img-centered" src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/05-preview.jpg'); ?>" alt="">
                            <p>Lorem ipsum dolor sit amet, sea essent iisque iudicabit te, pro no justo delicata inimicus et oblique docendi laboramus eum. Ei minim fabulas pertinacia pro graeco urbanitas reformidans quoid.</p>
                            <ul class="list-inline">
                                <li><span>Client</span>: John Doe</li>
                                <li><span>Service</span>: Web Design</li>
                            </ul>
                            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Portfolio Modal 6 -->
    <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal"><div class="lr"><div class="rl"> </div></div></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body"> 
                            <h2>Project Title</h2>
                            <p class="item-intro">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class="img-responsive img-centered" src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/06-preview.jpg'); ?>" alt="">
                            <p>Lorem ipsum dolor sit amet, sea essent iisque iudicabit te, pro no justo delicata inimicus et oblique docendi laboramus eum. Ei minim fabulas pertinacia pro graeco urbanitas reformidans quoid.</p>
                            <ul class="list-inline">
                                <li><span>Client</span>: John Doe</li>
                                <li><span>Service</span>: Web Design</li>
                            </ul>
                            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Portfolio Modal 7 -->
    <div class="portfolio-modal modal fade" id="portfolioModal7" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal"><div class="lr"><div class="rl"> </div></div></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body"> 
                            <h2>Project Title</h2>
                            <p class="item-intro">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class="img-responsive img-centered" src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/07-preview.jpg'); ?>" alt="">
                            <p>Lorem ipsum dolor sit amet, sea essent iisque iudicabit te, pro no justo delicata inimicus et oblique docendi laboramus eum. Ei minim fabulas pertinacia pro graeco urbanitas reformidans quoid.</p>
                            <ul class="list-inline">
                                <li><span>Client</span>: John Doe</li>
                                <li><span>Service</span>: Web Design</li>
                            </ul>
                            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Portfolio Modal 8 -->
    <div class="portfolio-modal modal fade" id="portfolioModal8" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal"><div class="lr"><div class="rl"> </div></div></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body"> 
                            <h2>Project Title</h2>
                            <p class="item-intro">Lorem ipsum dolor sit amet consectetur.</p>
                            <img class="img-responsive img-centered" src="<?php echo Yii::$app->urlManager->createAbsoluteUrl('theme-invictus/img/portfolio/08-preview.jpg'); ?>" alt="">
                            <p>Lorem ipsum dolor sit amet, sea essent iisque iudicabit te, pro no justo delicata inimicus et oblique docendi laboramus eum. Ei minim fabulas pertinacia pro graeco urbanitas reformidans quoid.</p>
                            <ul class="list-inline">
                                <li><span>Client</span>: John Doe</li>
                                <li><span>Service</span>: Web Design</li>
                            </ul>
                            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-times"></i> Close Project</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>