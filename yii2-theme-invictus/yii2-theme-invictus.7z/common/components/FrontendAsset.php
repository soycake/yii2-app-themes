<?php

namespace common\components;

use Yii; # ปิดการใช้งาน BootstrapAsset
use yii\web\AssetBundle;
use yii\web\View;

class FrontendAsset extends AssetBundle {
    
    # ปิดการใช้งาน BootstrapAsset
    public function init(){
        parent::init();
        Yii::$app->assetManager->bundles['yii\\bootstrap\\BootstrapAsset'] = [
            'css' => [],
            'js' => []
        ];
        Yii::$app->assetManager->bundles['yii\\bootstrap\\BootstrapPluginAsset'] = [
            'css' => [],
            'js' => []
        ];
        Yii::$app->assetManager->bundles['yii\\web\\JqueryAsset'] = [
            'js' => []
        ];
    }
    
    public $jsOptions = ['position' => View::POS_END];
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    
    public $css = [
        'theme-invictus/vendor/bootstrap-3.3.2/styles/bootstrap.min.css',
        'theme-invictus/vendor/font-awesome-4.6.1/css/font-awesome.min.css',
        'theme-invictus/css/style.css',
        'theme-invictus/vendor/animate-css-3.5.1/animate.min.css',
        'http://fonts.googleapis.com/css?family=Open+Sans:400,700,800,600,300',
        'theme-invictus/vendor/fancybox-2.1.5/source/jquery.fancybox.css',
        'theme-invictus/vendor/fancybox-2.1.5/source/helpers/jquery.fancybox-buttons.css',
        'theme-invictus/vendor/fancybox-2.1.5/source/helpers/jquery.fancybox-thumbs.css'
    ];
    
    public $js = [
        'theme-invictus/vendor/jquery-1.12.3/jquery.min.js',
        'theme-invictus/vendor/bootstrap-3.3.2/scripts/bootstrap.min.js',
        'theme-invictus/js/SmoothScroll.js',
        'theme-invictus/js/wow.min.js',
        'theme-invictus/js/jquery.counterup.js',
        'theme-invictus/js/waypoints.js',
        'theme-invictus/js/jquery.isotope.js',
        'theme-invictus/js/jqBootstrapValidation.js',
        'theme-invictus/js/contact_me.js',
        'theme-invictus/vendor/fancybox-2.1.5/lib/jquery.mousewheel-3.0.6.pack.js',
        'theme-invictus/vendor/fancybox-2.1.5/source/jquery.fancybox.pack.js',
        'theme-invictus/vendor/fancybox-2.1.5/source/helpers/jquery.fancybox-buttons.js',
        'theme-invictus/vendor/fancybox-2.1.5/source/helpers/jquery.fancybox-media.js',
        'theme-invictus/vendor/fancybox-2.1.5/source/helpers/jquery.fancybox-thumbs.js',
        'theme-invictus/js/main.js'
    ];
    
    public $depends = [];
    
}